module.exports = {
	extends: [
		'@nextcloud',
	],
}
