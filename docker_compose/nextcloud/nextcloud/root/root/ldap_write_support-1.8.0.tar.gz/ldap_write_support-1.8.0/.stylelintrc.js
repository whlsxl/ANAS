const stylelintConfig = require('@nextcloud/stylelint-config')

module.exports = stylelintConfig